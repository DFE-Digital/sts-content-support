﻿namespace ContentFul.ApI.Models
{
    //public class ContentComponent
    //{
    //}
    public abstract class ContentComponent //: IContentComponent
    {
        public SystemDetails Sys { get; init; } = null!;
    }
}
