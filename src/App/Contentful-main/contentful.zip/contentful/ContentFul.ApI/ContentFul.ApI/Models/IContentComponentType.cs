﻿namespace ContentFul.ApI.Models
{
    public interface IContentComponentType
    {
        //public SystemDetails Sys { get; set; }
    }
}
