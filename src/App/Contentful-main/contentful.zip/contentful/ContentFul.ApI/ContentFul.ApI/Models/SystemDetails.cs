﻿namespace ContentFul.ApI.Models
{
    public class SystemDetails
    {
        public string Id { get; init; } = null!;
    }
}
