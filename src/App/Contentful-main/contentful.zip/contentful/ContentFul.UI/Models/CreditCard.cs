namespace Projects.Models;

public class CreditCard
{
   public string Issuer { get; set; }

   public int Fee { get; set; }
    public string Type { get; set; }
}
